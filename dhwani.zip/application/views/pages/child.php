 <style type="text/css">
 	.card{
 		padding: 50px;
 	}
 </style>
 <div class="container">

<section class="py">
			 <div class="row">
				<div class="col-md-10">
					 
				</div>
				<div class="col-md-2" align="right">
					<a href="<?=base_url()?>add-child" id="add_button"class="btn btn-green btn-sm">Add Child</a>
				</div>
			</div>
			<br>
			<div class="card">
				<table id="example" class="table">
				<thead>
					<tr>
						<th scope="col">Name</th>
						<th scope="col">Sex</th>
						<th scope="col">Date Of Birth</th>
						<th scope="col">Father's Name</th>
						<th scope="col">Mother's Name</th>
						<th scope="col">State</th>
						<th scope="col">District</th>
						<th scope="col">Action</th>
					</tr>
				</thead>
				<tbody>
					<?php if (is_array($childdata) || is_object($childdata)):?>
					<?php foreach ($childdata as $key => $child): ?>
					<tr>
						<th scope="row"><?=ucfirst($child->child_name)?></th>
						<td><?=($child->gender ==='m')?'Male':'Female'?></td>
						<td><?=date("d/m/Y", strtotime($child->dob))?></td>
						<td><?=ucfirst($child->father_name)?></td>
						<td><?=ucfirst($child->mother_name)?></td>
						<td><?=ucfirst($child->state)?></td>
						<td><?=ucfirst($child->district_name)?></td>
						<td><a href="<?=base_url()?>view-child/<?=$child->id?>" id="add_button"class="btn btn-outline-success btn-sm">view</a></td>
					</tr>
					<?php endforeach ;?>
					<?php endif ;?>
				</tbody>
				</table>
			</div>
		
	</section>
</div>	
	