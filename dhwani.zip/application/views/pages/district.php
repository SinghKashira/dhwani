
<section class="py">
	<div class="container">  
				<div class="row">
						  <div class="col-sm-4">
						    <div class="card card-color">
						      <div class="card-body"> 
						           <div class="col-sm-12">
						           	<div class="row">
						           		<div class="d-inline-block my-2 w-100 show-error">
										</div>
						           	<div class="col-sm-4">
						           		<div class="circle"><i class="fa fa-plus"></i></div>
						           	</div>
						           	<div class="col-sm-8">
						           	   <form id="form_district" method="POST" accept-charset="utf-8">  
						           		 <div class="form-group"> 
										    <select class="form-control" name="state_id" id="exampleFormControlSelect1">
										      <option value=" ">Select State</option>
										      <?=$state?> 
										    </select>
										  </div>
						           		<input type="text" name="district_name" class="form-control" placeholder="Enter District Name">
						           		<button style="margin-top: 8px ;" class="btn btn-sm btn-green add" type="submit">ADD DISTRICT</button>
						           	</form>
						           	</div>
						           </div> 
						       </div>
						      </div>
						    </div>
						  </div>
						  <?php if (is_array($district) || is_object($state)){?>
						  <?php $n=1; foreach ($district as $key => $value): ?>
						  <div class="col-sm-4">
						    <div class="card card-color">
						      <div class="card-body"> 
						           	<div class="row">
							           	<div class="col-sm-3">
							           		<div class="circle circel-solid"><?=$n?></div>
							           	</div>
							           	<div class="col-sm-6 top-margin">
							           		<h5><?=ucfirst($value->state)?></h5>
							           		<h5><?=ucfirst($value->name)?></h5>
							           	</div>
							           	<div class="col-sm-3 top-margin">
							           		<span class="arrow">
							           			<i class="fa fa-arrow-right"></i>
							           		</span>
							           	</div>
						           </div>
						      </div>
						    </div>
						  </div>
						  <?php $n++; endforeach; }?>
					    </div>
					</div>
 
</section>