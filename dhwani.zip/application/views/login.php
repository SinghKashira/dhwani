<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Login</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/css/style.css">
		<body class="text-center">
			<form class="form-signin"  method="POST" id="formLogin">
				<img class="mb-4" src="<?=base_url()?>assets/images/logo.PNG" alt="" width="110" height="110">
				<h1 class="h5 mb-3 font-weight-bold">Login</h1>
				<div class="d-inline-block my-2 w-100 show-error">
				</div>
				<input type="text"  class="form-control" name="username" placeholder="Username">
				<input type="password" class="form-control" name="password" placeholder="Password">
				
				<button style="margin-top: 16px ;" class="btn btn-lg btn-success btn-block" type="submit">Log In</button>
				
				
			</form>
		</body>
		<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
		<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
		<?php $this->load->view('layouts/commonjs', FALSE);?>
	</html>