<?php 
  if(!empty($this->session->userdata('userDeails'))){
  $token = $this->session->userdata('userDeails')['token'];
}else{
  $token=null;
}
?>
<script type="text/javascript">
	$(function($) {
  "ues strict";
  var base_url = window.location.origin + '/dhawani-test/';
  $(document).ready(function() {
  $(document).on('submit', '#formLogin', function(e) {
    e.preventDefault();
    $.ajax({
      url: "<?=base_url()?>signin", // url where to submit the request
      type: "POST", // type of action POST || GET
      dataType: 'json', // data type
      data: $(this, ).serialize(), // post data || get data
      success: function(result) {
        console.log(result);
        if (result.status) {
          alertdata('.show-error', 'success', result.message);
          setTimeout(function() {
            window.location.href = '<?=base_url()?>home';
          }, 1000);
        } else {
          alertdata('.show-error', 'danger', result.message);
        }
      },
      error: function(xhr, resp, text) {
        console.log(xhr, resp, text);
      }
    })
  });
});
  $('#form_state').on('submit', function(event) {
    event.preventDefault();
    $.ajax({
      url: "<?=base_url()?>add-state",
      headers: {
        'token': '<?=$token?>'
      },
      method: "POST",
      data: $(this).serialize(),
      dataType: "json",
      beforeSend: function() {
        $('#add').attr('disabled', 'disabled');
      },
      success: function(data) {
          console.log(data);
        if (data.status) {
          alertdata('.show-error', 'success', data.message);
          setTimeout(function() {
            window.location.href = "<?=base_url('state')?>"
          }, 1000);
        } else {
        $('#add').removeAttr('disabled');
          alertdata('.show-error', 'danger', data.message);
        }
      }
    })
  });
  $('#form_district').on('submit', function(event) {
    event.preventDefault();
    $.ajax({
      url: "<?=base_url()?>add-district",
      headers: {
        'token': '<?=$token?>'
      },
      method: "POST",
      data: $(this).serialize(),
      dataType: "json",
      beforeSend: function() {
        $('#add').attr('disabled', 'disabled');
      },
      success: function(data) {
        if (data.status) {
          alertdata('.show-error', 'success', data.message);
          setTimeout(function() {
            location.reload();
          }, 1000);
        } else {
          alertdata('.show-error', 'danger', data.message);
        }
      }
    })
  });
  $(document).on('submit','#form_add_child', function(event) {
    event.preventDefault();
    var formData = new FormData(this);
    $.ajax({
      url: "<?=base_url()?>upload_child",
      headers: {
        'token': '<?=$token?>'
      },
      method: "POST",
      data:formData,
      cache:false,
      contentType: false,
      processData: false,
      dataType: "json",
      beforeSend: function() {
        $('#add').attr('disabled', 'disabled');
      },
      success: function(data) {
        if (data.status) {
          alertdata('.show-error', 'success', data.message);
          setTimeout(function() {
            window.location.href = '<?=base_url()?>child';
          }, 1000);
        } else {
          alertdata('.show-error', 'danger', data.message);
        }
      }
    })
  });
  $('#logout').on('click', function(event) {
    event.preventDefault();
    $.ajax({
      url: "<?=base_url()?>logout",
      headers: {
        'token': '<?=$token?>'
      },
      method: "POST",
      data: {
        date: 'logout'
      },
      dataType: "json",
      success: function(data) {
        if (data.status) { 
          setTimeout(function() {
            window.location.href = '<?=base_url()?>';
          }, 1000);
        } else {
          alertdata('.show-error', 'danger', data.message);
        }
      }
    })
  });
  $(document).on('change', '#selectstate', function(event) {
    event.preventDefault();
    var option = '';
    $.ajax({
      url: "<?=base_url()?>get-district",
      headers: {
        'token': '<?=$token?>'
      },
      method: "GET",
      data: {
        state_id: $(this).val()
      },
      dataType: "json",
      success: function(data) {
        if (data.status) {
          for (var i = 0; i < data.district.length; i++) {
            console.log(data.district[i]);
            option += '<option value=' + data.district[i]['id'] + '>' + data.district[i]['name'] + '</option>';
          }
          $('#selectdistrict').html(option);
        } else {
          alertdata('.show-error', 'danger', data.message);
        }
      }
    })
  });
});

function alertdata(field, type, data) {
  $(field).html('<div class="alert alert-' + type + '">' + data + '</div>');
  setTimeout(function() {
    $(field).hide()
  }, 5000);
};


$(".deletestate").click(function(){
    var con = confirm("Are You Sure To Delete This State??");
    if(con == true){
        console.log($(this).attr("state-id"));
        $.ajax({
            type:'post',
            url:'<?=base_url()?>delete-state',
            data:{stateid:$(this).attr("state-id")},
            dataType:'json',
            success:function(res){
                console.log(res);
                if (res.status) {
                  alertdata('.show-error', 'success', res.message);
                  setTimeout(function() {
                    location.reload();
                  }, 1000);
                } else {
                  alertdata('.show-error', 'danger', res.message);
                }
            }
        })
    }
})
</script>