<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Viewcontroller extends CI_Controller {
    public function __construct()
    {
    	parent::__construct();
    	$this->load->model(array('webmodel'=>'wm'));
    }
	public function login()
	{
		$this->load->view('login'); 
	}

	public function index()
	{
		if(!empty($this->session->userdata('userDeails')['token'])){
		$data = [
			'title'=>'Login',
			'body'=> 'pages/home',
			'nav' => 'layouts/navbar',
		];
		$this->load->view('master',$data, FALSE);
		}else{
			redirect('login','refresh');
		}
	}
	public function state($sid=null)
	{
	    if(!empty($sid)){
	        $wheredata['id'] = $sid;
	    }else{
	        $wheredata = null;
	    }
		if(!empty($this->session->userdata('userDeails')['token'])){
		$data = [
			'title'=>'Add State',
			'body'=> 'pages/state',
			'nav' => 'layouts/navbar',
			'sid' => $wheredata,
			'state'=>$this->wm->getState($wheredata)
		];
		$this->load->view('master',$data, FALSE);
		}else{
			redirect('login','refresh');
		}
	}
	public function district()
	{
		if(!empty($this->session->userdata('userDeails')['token'])){
		$data = [
			'title'=>'Add District',
			'body'=> 'pages/district',
			'nav' => 'layouts/navbar',
			'style' =>'layouts/css',
			'state'=> $this->selectstate(),
			'district'=>$this->wm->getdisrtict()
		]; 
		$this->load->view('master',$data, FALSE);
		}else{
			redirect('login','refresh');
		}
	}
	public function child()
	{
		if(!empty($this->session->userdata('userDeails')['token'])){
		$data = [
			'title'=>'View Child',
			'body'=> 'pages/child',
			'nav' => 'layouts/navbar',
			'style' =>'layouts/css',
			'childdata'=>$this->wm->getchild()
		];

		$this->load->view('master',$data, FALSE);
		}else{
			redirect('login','refresh');
		}
	}
	public function add_child()
	{
		if(!empty($this->session->userdata('userDeails')['token'])){
		$data = [
			'title'=>'Add Child',
			'body'=> 'pages/add-child',
			'nav' => 'layouts/navbar',
			'style' =>'layouts/css',
			'state'=> $this->selectstate(),
			'district'=> $this->selectdistict(),
		];
		$this->load->view('master',$data, FALSE);
		}else{
			redirect('login','refresh');
		}
	}
	public function view_child()
	{    
		if(!empty($this->session->userdata('userDeails')['token'])){
		$data = [
			'title'=>'View Child',
			'body'=> 'pages/viewchild',
			'nav' => 'layouts/navbar',
			'style' =>'layouts/css',
			'childdata'=>$this->wm->getchild($this->uri->segment(2))
		];
		$this->load->view('master',$data, FALSE);
		}else{
			redirect('login','refresh');
		}
	}


	public function selectdistict($id = null)
	{
		$option = '';
		$distict = $this->wm->getdisrtict();
		if($distict){
    		foreach ($distict as $key => $distictSelect) {
    			$option .= "<option  ".($id !== null?($distictSelect->id == $id?'selected':''):'')."  value=".$distictSelect->id.">".$distictSelect->name."</option>";
    		}
	    }
		return $option;
	}
	public function selectstate($id = null)
	{
		$option = '';
		$state = $this->wm->getState();
		if($state){
    		foreach ($state as $key => $getState) {
    			$option .= "<option  ".($id !== null?($getState->id == $id?'selected':''):'')."  value=".$getState->id.">".$getState->state."</option>";
    		}
	    }
		return $option;
	}
}
