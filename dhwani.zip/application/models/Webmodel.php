<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Webmodel extends CI_Model {
public function __construct()
{
	parent::__construct();
	//Do your magic here
}
	public function state($data)
	{ 
		$data=  $this->db->insert('state',$data);
		if ($this->db->affected_rows() > 0) {
			return true;
		}else{
			return false;
		} 
	}
	
	public function updatestate($data,$id){
	    $this->db->set($data)->where('id',$id)->update("state");
	    return true;
	}
	public function getState($data=null)
	{
		$this->db->select('id,state');
		if (!empty($data)) {
			$this->db->where($data);
		}
		$this->db->order_by('id', 'desc');
		$select= $this->db->get('state');
		 if ($select->num_rows() > 0) {
		 	return $select->result();
		 }else{
		 	return false;
		 }
	}
	
	public function delState($sid){
	    $res = $this->db->where("id",$sid)->delete("state");
	    if($res){
	        return true;
	    }else{
	        return false;
	    }
	}
	public function disrtict($data)
	{ 
		$data=  $this->db->insert('district',$data);
		if ($this->db->affected_rows() > 0) {
		return true;
		}else{
			return false;
		} 
	}
	public function getdisrtict($data=null)
	{
		//return $data;
		$this->db->select('d.id,d.name,s.state');
		if (!empty($data['search'])) {
			$this->db->or_where(array('d.state_id'=>$data['search'],'d.name'=>$data['search']));
		}
		$this->db->from('district d');
		$this->db->join('state s','d.state_id=s.id','inner');
		$this->db->order_by('d.id', 'desc');
		$select= $this->db->get();
		//die($this->db->last_query());
		if ($select->num_rows() > 0) {
		 	return $select->result();
		}else{
			return false;
		}
	}
	public function addchild($data)
	{ 
		$data=  $this->db->insert('child',$data);
		if ($this->db->affected_rows() > 0) {
			 $return_data = $this->db->select('*')->from('child')->order_by('id','DESC')->limit('1')->get()->result_array();
		return $return_data;
		}else{
			return false;
		} 
	}
	public function getchild($data=null)
	{
		$this->db->select('c.id,c.name as child_name,c.gender,c.dob,c.father_name,c.mother_name,c.image,s.state,d.name as district_name')->from('child c')->join('district d','d.id=c.district','inner')->join('state s','s.id=c.state','inner')->order_by('c.id','desc');
		if (!empty($data)) {
			$this->db->where('c.id',$data);
		}
		$select= $this->db->get();
		 if ($select->num_rows() > 0) {
		 	return $select->result();
		 }
	}

}
