<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	class Authmodel extends CI_Model {
		public function __construct(){
			parent::__construct();
		} 
		public function login($data){
			$this->db->select('*');
			$this->db->from('tbl_users');
			$this->db->where(array('username'=>$data['username'], 'password'=>$data['password']));
			$query = $this->db->get();
			if($query->num_rows() > 0){
				return $query->row_array();
			}else{
				return false;
			}
		}

	}